### January 21, 2016

* Taiga is now in BEM.
* Added the ITCSS mindset of Harry Roberts.
* [CSS Guidelines](Guidelin.es) added.
