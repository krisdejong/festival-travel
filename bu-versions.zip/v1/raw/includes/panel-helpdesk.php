<dl class="is-advanced u-no-spacing">
  <dt>Helpdesk:</dt>
  <dd><a href="tel:0203080854" class="neutral-link">020 - 308 08 54</a></dd>

  <dt class="u-no-spacing">Mail versturen:</dt>
  <dd class="u-no-spacing"><a href="tel:0203080854" class="neutral-link">Mail versturen</a></dd>
</dl>
