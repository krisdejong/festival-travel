<ul class="c-products">
  <li class="c-products__item">
    <strong class="c-products__title">1 x 7 Days pass ticket</strong>
    <p class="u-no-spacing is-small">12 juli 2016 t/m 21 juli 2016</p>
    <small class="c-products__count">(Nog 6)</small>
  </li>
  <li class="c-products__item">
    <strong class="c-products__title">1 x Camping Alternativa</strong>
    <p class="u-no-spacing is-small">12 juli 2016 t/m 21 juli 2016</p>
    <small class="c-products__count">(Nog 4)</small>
  </li>
  <li class="c-products__item">
    <strong class="c-products__title">1 x 7 Days pass ticket</strong>
    <p class="u-no-spacing is-small">12 juli 2016 t/m 21 juli 2016</p>
    <small class="c-products__count">(Nog 4)</small>
  </li>
  <li class="c-products__item c-products__item--disabled">
    <strong class="c-products__title">1 x Bustransfer retour (luxe zitplaatsen)</strong>
    <p class="u-no-spacing is-small">12 juli 2016 t/m 21 juli 2016</p>
  </li>
  <li class="c-products__item c-products__item--disabled">
    <strong class="c-products__title">Festival kluis</strong>
  </li>
</ul>