<table class="u-no-spacing">
<!--   <thead>
    <tr>
      <th>Factuur</th>
      <th>Datum</th>
      <th>Bedrag</th>
    </tr>
  </thead> -->
  <tbody>
    <tr>
      <td><a class="neutral-link neutral-link--icon"><svg class="o-icon o-icon--inline"><use xlink:href="#icon-file" /></svg>FT2013042013</a></td>
      <td>28-02-15</td>
      <td>&euro; 123</td>
    </tr>
    <tr>
      <td><a class="neutral-link neutral-link--icon"><svg class="o-icon o-icon--inline"><use xlink:href="#icon-file" /></svg>FT2013042013</a></td>
      <td>28-02-15</td>
      <td>&euro; 123</td>
    </tr>
    <tr>
      <td><a class="neutral-link neutral-link--icon"><svg class="o-icon o-icon--inline"><use xlink:href="#icon-file" /></svg>FT2013042013</a></td>
      <td>28-02-15</td>
      <td>&euro; 123</td>
    </tr>
    <tr>
      <td><a class="neutral-link neutral-link--icon"><svg class="o-icon o-icon--inline"><use xlink:href="#icon-file" /></svg>FT2013042013</a></td>
      <td>28-02-15</td>
      <td>&euro; 123</td>
    </tr>
  </tbody>
</table>