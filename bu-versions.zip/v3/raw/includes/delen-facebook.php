<li class="o-messages__item o-messages__item--has-button">
  Snel klaar zijn? Registreer met jouw Facebook account <a class="o-button o-button--facebook"><svg class="o-icon o-icon--inline"><use xlink:href="#facebook-icon" /></svg>Inloggen met Facebook</a>
</li>